#!/bin/sh

timeout 60 /home/jackpot/jackpot
