#!/bin/sh

timeout 60 /home/chal/chal
